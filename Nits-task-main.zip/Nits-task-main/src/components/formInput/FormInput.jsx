import React from "react";

function FormInput({ label, ...otherProps }) {
  return (
    <div className="group mb-2">
      <label>{label}</label>
      <input className="form-control" {...otherProps} />
    </div>
  );
}

export default FormInput;
