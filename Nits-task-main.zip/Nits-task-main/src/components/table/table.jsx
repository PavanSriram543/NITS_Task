import React, { Component } from "react";
import RecordDialog from "./RecordDialog";
import { Users_data } from "./state";

class UserData extends Component {
  constructor(props) {
    super(props);
    this.state = {
      users: Users_data,
      id: "",
      name: "",
      designation: "",
      email: "",
      items: [],
      isModalOpen: false,
      action: "",
      userToUpdate: null,
      submitHandler: null,
      sortHeadersState: {
        idAscending: true,
        nameAscending: true,
        designationAscending: true,
        emailAscending: true,
      },
    };
  }
  handleChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  };
  deleteRecord = (id) => {
    const deletedpost = this.state.users.filter((user) => user.id !== id);
    this.setState({ users: deletedpost });
  };
  createUser = (user) => {
    const users = [...this.state.users];
    users.push(user);
    this.setState({ users });
    this.toggleModal();
    console.log(users);
  };
  updateRecord = (newRecord) => {
    console.log(newRecord);

    let items = [...this.state.users];
    let newItems = items.map((item) => {
      if (item.id === newRecord.id) {
        alert("Successfully Updated");
        console.log("item", item);
        let newObj = {
          id: newRecord.id,
          name: newRecord.name,
          designation: newRecord.designation,
          email: newRecord.email,
        };
        return {
          ...newObj,
        };
      } else {
        return item;
      }
    });
    console.log("newItems.......newItems", newItems);
    this.setState(
      {
        users: newItems,
      },
      () => {
        this.setState({ userToUpdate: null });
      }
    );

    this.toggleModal();
  };

  toggleModal = () => {
    this.setState({ isModalOpen: !this.state.isModalOpen });
  };

  handleActionClick = (action, id) => {
    this.setState({ action }, () => {
      this.setSubmitHandler();
      if (this.state.action === "update") {
        this.handleUpdateClick(id);
      }
      this.toggleModal();
    });
  };

  setSubmitHandler = () => {
    if (this.state.action === "create") {
      this.setState({ submitHandler: this.createUser });
    } else if (this.state.action === "update") {
      this.setState({ submitHandler: this.updateRecord });
    }
  };

  handleUpdateClick = (id) => {
    const _user = this.state.users.find((user) => user.id === id);

    this.setState({ userToUpdate: _user }, () => {
      console.log(this.state.userToUpdate);
    });
  };
  handleSorting = (key, sortBy) => {
    const _sortedUsers = this.state.users.sort((a, b) => {
      if (key === "id") {
        const _aInt = parseInt(a[key]);
        const _bInt = parseInt(b[key]);

        return this.compareNumbers(_aInt, _bInt);
      } else {
        var nameA = a[key].toUpperCase();
        var nameB = b[key].toUpperCase();

        if (nameA < nameB) {
          return this.state.sortHeadersState[sortBy] ? -1 : 1;
        }

        if (nameA > nameB) {
          return this.state.sortHeadersState[sortBy] ? 1 : -1;
        }

        return 0;
      }
    });

    this.setState({
      sortHeadersState: {
        [sortBy]: !this.state.sortHeadersState[sortBy],
      },
    });

    this.setState({ users: _sortedUsers });
  };

  compareNumbers = (a, b) => {
    return a - b;
  };
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-12 text-center p-4">
            <h1>Welcome to NITS</h1>
            <h4>User Details</h4>
          </div>
          <button
            type="button"
            className="btn btn-primary w-auto"
            onClick={() => this.handleActionClick("create")}
          >
            + Add new user{" "}
          </button>
          <table className="table table-striped table-dark">
            <thead>
              <tr className="table-primary text-dark">
                <th
                  onClick={() => this.handleSorting("id", "idAscending")}
                  scope="col"
                >
                  id
                </th>
                <th
                  scope="col"
                  onClick={() => this.handleSorting("name", "nameAscending")}
                >
                  Name
                </th>
                <th
                  scope="col"
                  onClick={() =>
                    this.handleSorting("designation", "designationAscending")
                  }
                >
                  Designation
                </th>
                <th
                  scope="col"
                  onClick={() => this.handleSorting("email", "emailAscending")}
                >
                  Email
                </th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.users.map((user, id) => (
                <tr key={id} className="table-primary text-dark">
                  <td>{user.id}</td>
                  <td>{user.name}</td>
                  <td>{user.designation}</td>
                  <td>{user.email}</td>
                  <td>
                    <i
                      type="button"
                      className="fas fa-user-edit"
                      onClick={() => this.handleActionClick("update", user.id)}
                    />{" "}
                    &nbsp;
                    <i
                      type="button"
                      className="fas fa-user-minus"
                      onClick={() => this.deleteRecord(user.id)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <RecordDialog
            action={this.state.action}
            isModalOpen={this.state.isModalOpen}
            userToUpdate={this.state.userToUpdate}
            submitHandler={this.state.submitHandler}
          />
        </div>
      </div>
    );
  }
}

export default UserData;
