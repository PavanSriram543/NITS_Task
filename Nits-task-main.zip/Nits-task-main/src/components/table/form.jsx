import React, { useState, useEffect } from "react";
import FormInput from "../formInput/FormInput";

const Form = ({ action, submitHandler, userToUpdate }) => {
  const [user, setUser] = useState({
    id: "",
    name: "",
    designation: "",
    email: "",
  });

  useEffect(() => {
    console.log(userToUpdate);
    if (userToUpdate && action === "update") {
      setUser(userToUpdate);
    }
  }, [userToUpdate]);

  const handleSubmitBtnClick = () => {
    submitHandler(user);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const { id, name, designation, email } = user;

  return (
    <div className="container">
      <h1>Add user details</h1>
      <form>
        <div className="form-group">
          <FormInput
            type="text"
            name="id"
            value={id}
            label="ID"
            onChange={handleChange}
            disabled={action === "update"}
          />
        </div>
        <div className="form-group pb-2">
          <FormInput
            type="text"
            name="name"
            value={name}
            label="Name"
            onChange={handleChange}
          />
        </div>
        <div className="form-group pb-2">
          <FormInput
            type="text"
            name="designation"
            value={designation}
            label="Designation"
            onChange={handleChange}
          />
        </div>
        <div className="form-group pb-2">
          {" "}
          <FormInput
            type="email"
            name="email"
            value={email}
            label="Email"
            onChange={handleChange}
          />
        </div>
        <button
          type="button"
          className="btn btn-primary btn-block "
          data-bs-dismiss="modal"
          onClick={handleSubmitBtnClick}
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default Form;
