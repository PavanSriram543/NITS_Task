export const Users_data = [
  {
    id: "1",
    name: "sam",
    designation: "tester",
    email: "sam@hmail.com",
  },
  {
    id: "2",
    name: "sunder",
    designation: "developer",
    email: "sunder@hmail.com",
  },
  {
    id: "3",
    name: "ram",
    designation: "tester",
    email: "ram@hmail.com",
  },
  {
    id: "4",
    name: "babu",
    designation: "developer",
    email: "babu@hmail.com",
  },
  {
    id: "5",
    name: "cal",
    designation: "tester",
    email: "cal@hmail.com",
  },
  {
    id: "6",
    name: "sam",
    designation: "developer",
    email: "sam@hmail.com",
  },
  {
    id: "7",
    name: "mike",
    designation: "tester",
    email: "mike@hmail.com",
  },
  {
    id: "8",
    name: "jhon",
    designation: "developer",
    email: "jhon@hmail.com",
  },
  {
    id: "9",
    name: "jack",
    designation: "tester",
    email: "jack@hmail.com",
  },
  {
    id: "10",
    name: "somu",
    designation: "developer",
    email: "somu@hmail.com",
  },
];
