import React from "react";
import { Modal, ModalBody } from "reactstrap";
import Form from "./form";

const RecordDialog = ({
  action,
  isModalOpen,
  submitHandler,
  toggleModal,
  userToUpdate,
}) => {
  return (
    <div>
      <Modal isOpen={isModalOpen} toggle={toggleModal}>
        <ModalBody>
          <Form
            action={action}
            submitHandler={submitHandler}
            userToUpdate={userToUpdate}
          />
        </ModalBody>
      </Modal>
    </div>
  );
};

export default RecordDialog;
