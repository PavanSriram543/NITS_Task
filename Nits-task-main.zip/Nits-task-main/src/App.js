import React from "react";
import { BrowserRouter as Switch, Route, withRouter } from "react-router-dom";
import "./App.css";
import RegistrationPage from "./pages/registrationPage";
import WelcomePage from "./pages/welcomePage";

function App() {
  return (
    <div className="App">
      <Switch>
        <Route exact path="/">
          <RegistrationPage />
        </Route>
        <Route path="/welcome">
          <WelcomePage />
        </Route>
      </Switch>
    </div>
  );
}

export default withRouter(App);
