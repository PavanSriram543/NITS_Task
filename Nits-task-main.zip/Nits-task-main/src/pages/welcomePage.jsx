import React, { Component } from "react";
import Table from "../components/table/table";

class WelcomePage extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div>
        <Table />
      </div>
    );
  }
}

export default WelcomePage;
