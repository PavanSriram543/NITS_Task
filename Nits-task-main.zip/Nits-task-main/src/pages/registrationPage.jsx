import React, { useState } from "react";
import FormInput from "../components/formInput/FormInput";

import { useHistory } from "react-router-dom";

function RegistrationPage() {
  const [user, setUser] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const history = useHistory();
  const handleSubmit = (event) => {
    event.preventDefault();

    const { username, email, password, confirmPassword } = user;

    if (!username || !email || !password || !confirmPassword) {
      alert("Please fill all the fields");
      return;
    }

    if (password !== confirmPassword) {
      alert("passwords don't match");
      return;
    }
    alert("form submited");
    routeChange();
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setUser((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  const routeChange = () => {
    history.push("/welcome");
  };

  const { username, email, password, confirmPassword } = user;
  return (
    <div className="sign-up p-4">
      <div className="p-4 border">
        <h2 className="title">Registrtaion Form</h2>
        <span>Sign up with your email and password</span>
        <form className="sign-up-form " onSubmit={handleSubmit}>
          <FormInput
            type="text"
            name="username"
            value={username}
            onChange={handleChange}
            label="User Name"
            required
          />
          <FormInput
            type="email"
            name="email"
            value={email}
            onChange={handleChange}
            label="Email"
            required
          />
          <FormInput
            type="password"
            name="password"
            value={password}
            onChange={handleChange}
            label="Password"
            required
          />
          <FormInput
            type="password"
            name="confirmPassword"
            value={confirmPassword}
            onChange={handleChange}
            label="Confirm Password"
            required
          />
          <button className="btn btn-primary" onClick={handleSubmit}>
            Sign up{" "}
          </button>
        </form>
      </div>
    </div>
  );
}

export default RegistrationPage;
